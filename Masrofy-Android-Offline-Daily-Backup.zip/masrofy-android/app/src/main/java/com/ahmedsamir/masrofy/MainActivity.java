package com.ahmedsamir.masrofy;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import androidx.work.*;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
  WebView web; ValueCallback<Uri[]> fileCallback; static final int PICK_BACKUP=41, SAVE_BACKUP=42;
  String pendingJson="";
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(0xFF101820);getWindow().setNavigationBarColor(0xFF101820);
    scheduleBackup(); web=new WebView(this); setContentView(web);
    WebSettings ws=web.getSettings(); ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setAllowFileAccess(true); ws.setAllowContentAccess(true); ws.setDatabaseEnabled(true); ws.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
    web.setOverScrollMode(View.OVER_SCROLL_NEVER); web.addJavascriptInterface(new BackupBridge(),"AndroidBackup");
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params){ if(fileCallback!=null)fileCallback.onReceiveValue(null); fileCallback=cb; Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,PICK_BACKUP);return true; }
    });
    web.setWebViewClient(new WebViewClient()); web.loadUrl("file:///android_asset/www/index.html");
  }
  private void scheduleBackup(){ PeriodicWorkRequest req=new PeriodicWorkRequest.Builder(BackupWorker.class,24,TimeUnit.HOURS).build(); WorkManager.getInstance(this).enqueueUniquePeriodicWork("masrofy_daily_backup",ExistingPeriodicWorkPolicy.KEEP,req); }
  public class BackupBridge {
    @JavascriptInterface public void saveBackup(String json){ if(json==null||json.length()>10_000_000)return; getSharedPreferences("masrofy",0).edit().putString("latest_backup",json).apply(); writeLocalBackup(json,false); }
    @JavascriptInterface public void exportBackup(String json){ if(json==null||json.length()>10_000_000)return; runOnUiThread(()->{pendingJson=json;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"masrofy-backup-"+day()+".json");startActivityForResult(i,SAVE_BACKUP);}); }
    @JavascriptInterface public String backupStatus(){
      if(android.os.Build.VERSION.SDK_INT>=29){ try(android.database.Cursor cur=getContentResolver().query(android.provider.MediaStore.Downloads.getContentUri(android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY),new String[]{android.provider.MediaStore.MediaColumns._ID},android.provider.MediaStore.MediaColumns.RELATIVE_PATH+"=?",new String[]{"Download/Masrofy Backups/"},null)){return cur==null?"0":String.valueOf(cur.getCount());}catch(Exception ignored){return "0";} }
      File d=new File(getFilesDir(),"backups");File[] f=d.listFiles((dir,name)->name.endsWith(".json"));return f==null?"0":String.valueOf(f.length);
    }
  }
  static String day(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
  static void writeLocalBackup(Context c,String json,boolean daily){
    try {
      if (android.os.Build.VERSION.SDK_INT >= 29) writePublicBackup(c,json,daily);
      else {
        File dir=new File(c.getFilesDir(),"backups"); if(!dir.exists()) dir.mkdirs();
        write(new File(dir,"latest.json"),json);
        if(daily) write(new File(dir,"masrofy-backup-"+day()+".json"),json);
        else { File today=new File(dir,"masrofy-backup-"+day()+".json"); if(!today.exists()) write(today,json); }
        prunePrivate(dir);
      }
    } catch(Exception ignored) {}
  }
  @android.annotation.TargetApi(29)
  static void writePublicBackup(android.content.Context c,String json,boolean daily) throws Exception {
    android.content.ContentResolver cr=c.getContentResolver();
    android.net.Uri collection=android.provider.MediaStore.Downloads.getContentUri(android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY);
    String folder="Download/Masrofy Backups";
    String dated="Masrofy-backup-"+day()+".json";
    putDownload(cr,collection,folder,dated,json,daily);
    putDownload(cr,collection,folder,"Masrofy-latest.json",json,false);
    prunePublic(cr,collection,folder);
  }
  @android.annotation.TargetApi(29)
  static void putDownload(android.content.ContentResolver cr,android.net.Uri collection,String folder,String name,String json,boolean keepExisting) throws Exception {
    String selection=android.provider.MediaStore.MediaColumns.DISPLAY_NAME+"=? AND "+android.provider.MediaStore.MediaColumns.RELATIVE_PATH+"=?";
    String[] args={name,folder+"/"};
    try(android.database.Cursor cur=cr.query(collection,new String[]{android.provider.MediaStore.MediaColumns._ID},selection,args,null)){
      if(cur!=null && cur.moveToFirst()){
        if(keepExisting) return;
        android.net.Uri old=android.content.ContentUris.withAppendedId(collection,cur.getLong(0)); cr.delete(old,null,null);
      }
    }
    android.content.ContentValues values=new android.content.ContentValues();
    values.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME,name);
    values.put(android.provider.MediaStore.MediaColumns.MIME_TYPE,"application/json");
    values.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH,folder+"/");
    values.put(android.provider.MediaStore.MediaColumns.IS_PENDING,1);
    android.net.Uri uri=cr.insert(collection,values); if(uri==null) throw new java.io.IOException("Unable to create backup");
    try(java.io.OutputStream out=cr.openOutputStream(uri,"w")){ if(out==null) throw new java.io.IOException("Unable to open backup"); out.write(json.getBytes("UTF-8")); out.flush(); }
    android.content.ContentValues done=new android.content.ContentValues(); done.put(android.provider.MediaStore.MediaColumns.IS_PENDING,0); cr.update(uri,done,null,null);
  }
  @android.annotation.TargetApi(29)
  static void prunePublic(android.content.ContentResolver cr,android.net.Uri collection,String folder){
    try {
      String selection=android.provider.MediaStore.MediaColumns.RELATIVE_PATH+"=?";
      try(android.database.Cursor cur=cr.query(collection,new String[]{android.provider.MediaStore.MediaColumns._ID,android.provider.MediaStore.MediaColumns.DISPLAY_NAME},selection,new String[]{folder+"/"},null)){
        if(cur==null)return;
        java.util.ArrayList<android.net.Uri> old=new java.util.ArrayList<>();
        while(cur.moveToNext()){
          String n=cur.getString(1);
          if(n!=null && n.startsWith("Masrofy-backup-") && n.endsWith(".json")){
            String date=n.substring("Masrofy-backup-".length(),n.length()-5);
            try { java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US); f.setLenient(false); java.util.Date d=f.parse(date); if(d!=null && System.currentTimeMillis()-d.getTime()>45L*24*60*60*1000) old.add(android.content.ContentUris.withAppendedId(collection,cur.getLong(0))); } catch(Exception ignored){}
          }
        }
        for(android.net.Uri u:old) cr.delete(u,null,null);
      }
    } catch(Exception ignored){}
  }
  static void prunePrivate(File dir){ File[] fs=dir.listFiles((d,n)->n.startsWith("masrofy-backup-")&&n.endsWith(".json")); if(fs!=null&&fs.length>45){Arrays.sort(fs,(a,b)->Long.compare(b.lastModified(),a.lastModified()));for(int i=45;i<fs.length;i++)fs[i].delete();} }
  static void write(File f,String s)throws Exception{try(FileOutputStream o=new FileOutputStream(f)){o.write(s.getBytes("UTF-8"));o.getFD().sync();}}
  @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==PICK_BACKUP&&fileCallback!=null){Uri[] u=c==RESULT_OK&&d!=null?new Uri[]{d.getData()}:null;fileCallback.onReceiveValue(u);fileCallback=null;}else if(r==SAVE_BACKUP&&c==RESULT_OK&&d!=null){try(OutputStream o=getContentResolver().openOutputStream(d.getData())){o.write(pendingJson.getBytes("UTF-8"));Toast.makeText(this,"تم تصدير النسخة الاحتياطية",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"تعذر حفظ النسخة",Toast.LENGTH_LONG).show();}}}
  @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}

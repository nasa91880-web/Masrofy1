package com.ahmedsamir.masrofy;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
public class BackupWorker extends Worker {
 public BackupWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);}
 @NonNull @Override public Result doWork(){Context c=getApplicationContext();String j=c.getSharedPreferences("masrofy",0).getString("latest_backup",null);if(j!=null&&!j.isEmpty())MainActivity.writeLocalBackup(c,j,true);return Result.success();}
}
